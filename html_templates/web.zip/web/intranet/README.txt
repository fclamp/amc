
This directory contains pages, objects and files that required password or intranet only protection.

This directory should be restricted using the Web Servers password protection features. eg: .htaccess
