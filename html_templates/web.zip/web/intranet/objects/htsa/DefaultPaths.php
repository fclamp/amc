<?php
$STRINGS_DIR            = "$WEB_ROOT/intranet/objects/$BACKEND_TYPE/strings/";

// Default pages
$DEFAULT_QUERY_PAGE             = "/$WEB_DIR_NAME/intranet/pages/$BACKEND_TYPE/Query.php";
$DEFAULT_RESULTS_PAGE           = "/$WEB_DIR_NAME/intranet/pages/$BACKEND_TYPE/ResultsList.php";
$DEFAULT_CONTACT_SHEET_PAGE     = "/$WEB_DIR_NAME/intranet/pages/$BACKEND_TYPE/ContactSheet.php";
$DEFAULT_DISPLAY_PAGE           = "/$WEB_DIR_NAME/intranet/pages/$BACKEND_TYPE/Display.php";
$DEFAULT_PARTY_DISPLAY_PAGE     = "/$WEB_DIR_NAME/intranet/pages/$BACKEND_TYPE/PartyDisplay.php";
$DEFAULT_IMAGE_DISPLAY_PAGE = "/$WEB_DIR_NAME/intranet/pages/common/imagedisplay.php";
?>

