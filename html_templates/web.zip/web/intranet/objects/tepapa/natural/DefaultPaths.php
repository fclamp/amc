<?php
$STRINGS_DIR 		= "$WEB_ROOT/intranet/objects/$BACKEND_TYPE/strings/";

// Default pages
$DEFAULT_QUERY_PAGE		= "/$WEB_DIR_NAME/intranet/pages/$BACKEND_TYPE/natural/Query.php";
$DEFAULT_RESULTS_PAGE		= "/$WEB_DIR_NAME/intranet/pages/$BACKEND_TYPE/natural/ResultsList.php";
$DEFAULT_CONTACT_SHEET_PAGE	= "/$WEB_DIR_NAME/intranet/pages/$BACKEND_TYPE/natural/ContactSheet.php";
$DEFAULT_DISPLAY_PAGE		= "/$WEB_DIR_NAME/intranet/pages/$BACKEND_TYPE/natural/Display.php";
$DEFAULT_PARTY_DISPLAY_PAGE	= "/$WEB_DIR_NAME/intranet/pages/$BACKEND_TYPE/natural/PartyDisplay.php";
