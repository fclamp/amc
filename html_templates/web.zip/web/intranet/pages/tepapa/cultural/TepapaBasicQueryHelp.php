<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<title>Help</title>
</head>

<body bgcolor="#FFFFE8">

<table border="0" width="30%" cellspacing="0" cellpadding="8">
  <tr>
    <td width="10%" nowrap>
      <p align="center"><img border="0" src="../images/column.jpg" width="84" height="123">
    </td>
    <td width="45%">
      <h3><font face="Tahoma" color="#336699">Help</font></h3>
    </td>
  </tr>
</table>
<p><font face="Tahoma" color="#336699">In the first empty box, enter a term (or
terms) you wish to search for.</font></p>
<p><font face="Tahoma" color="#336699"><b><font size="2">Find: </font></b><input type="hidden" value="BasicQueryForm" name="QueryFormName">
<input type="hidden" value="1" name="StartAt"> <input name="BasicQueryTerms" size="20"></font></p>
<p><font face="Tahoma" color="#336699">The second window provides a way of
searching a specific collection area.&nbsp; Click on the drop-down arrow and
select the area in the collection you wish to search.&nbsp; If you don't select
an option here, &quot;anywhere&quot; remains the default which means the entire
collection will be searched.</font></p>
<p><select name="QueryType">
  <option value="any" selected>Anywhere</option>
  <option value="cla">Classification</option>
  <option value="pro">Production</option>
  <option value="ass">Association</option>
  <option value="web">Web Summary</option>
</select>&nbsp;&nbsp;&nbsp;</p>

</body>

</html>

