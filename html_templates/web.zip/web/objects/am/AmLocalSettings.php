<?php
$WEB_DIR_NAME = 'emuwebam-all';
$GLOBALS{'WEB_NOIMAGE_THUMB'} = "/$WEB_DIR_NAME/objects/am/images/noimage.gif";
$GLOBALS{'WEB_NOIMAGE_GRAPHIC'} = "/$WEB_DIR_NAME/objects/am/images/noimage.gif";
$GLOBALS{'WEB_NOIMAGE_THUMB_FILE'} = "$WEB_ROOT/objects/am/images/noimage.gif";
$GLOBALS{'WEB_NOIMAGE_GRAPHIC_FILE'} = "$WEB_ROOT/objects/am/images/noimage.gif";
?>

