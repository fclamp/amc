<?php 
$GLOBALS['NARRATIVE_KEYWORDS'] = array( 
	"test" => array(1, array()), 
	"machinery" => array(0, array(5)), 
	"subject1" => array(0, array(1)), 
	"subject 1" => array(0, array(2)), 
	"subject3" => array(0, array(1)), 
	"keyword" => array(0, array(2, 1)), 
	"keyword-4" => array(0, array(2)), 
	"camera" => array(0, array(3, 4)), 
	"manchester" => array(0, array(3)), 
	"photographs" => array(0, array(4)), 
	"subject-2" => array(0, array(2)), 
	"subject" => array(1, array()), 
	"keyword2" => array(0, array(1)), 
	"test data" => array(1, array()), 
	"ferranti" => array(0, array(3, 4, 5)), 
	"cameras" => array(0, array(5)), 
	"test data only" => array(0, array(1)), 
); 
?>
