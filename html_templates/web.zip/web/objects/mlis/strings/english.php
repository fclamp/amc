<?php
$STRINGS = array(
	"LANGUAGE"		=> "English",


// Query Field Names
	"Dc1Identifier"		=> "Identifier",
	"Dc1Subject_tab"	=> "Keywords",
	"Dc1Title"		=> "Title",
	"Dc1CreatorRef_tab->eparties->SummaryData"	=> "Creator",
	"Dc2DateCreated"	=> "Creation Date",

// Query Form Strings
	"DEFAULT_QUERY_TITLE"	=> "Search the Images...",
	"QUERY_OPTION_CREATOR"	=> "Creator",
	"QUERY_OPTION_OBJECT"	=> "Object Name",
	"QUERY_OPTION_TITLE"	=> "Title",
	"NUMBER_OF_RECORDS"	=> "Records per page",
	"ONLY_WITH_IMAGES"	=> "List works only with images",

// Results List Strings
	"Dc1CreatorLocal:1"	=> "Creator",
// Display Strings
	"CREATOR"		=> "Creator",
	);
?>
