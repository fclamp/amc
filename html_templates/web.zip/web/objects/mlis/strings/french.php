<?php
$STRINGS = array(
	"LANGUAGE"		=> "French",


// Query Field Names
	"Dc1Identifier"		=> "Accession Number / Identifier [TO BE TRANSLATED]",
	"Dc1Subject_tab"	=> "Keywords [TO BE TRANSLATED]",
	"Dc1Title"		=> "Title [TO BE TRANSLATED]",
	"Dc1CreatorRef_tab->eparties->SummaryData"	=> "Creator [TO BE TRANSLATED]",
	"Dc2DateCreated"	=> "Creation Date [TO BE TRANSLATED]",

// Query Form Strings
	"QUERY_OPTION_CREATOR"	=> "Creator [TO BE TRANSLATED]",
	"QUERY_OPTION_OBJECT"	=> "Object Name [TO BE TRANSLATED]",
	"QUERY_OPTION_TITLE"	=> "Title [TO BE TRANSLATED]",
	"NUMBER_OF_RECORDS"	=> "Records per page [TO BE TRANSLATED]",
	"ONLY_WITH_IMAGES"	=> "List works only with images [TO BE TRANSLATED]",

// Display Strings
	"CREATOR"		=> "Creator [TO BE TRANSLATED]",
	);
?>
