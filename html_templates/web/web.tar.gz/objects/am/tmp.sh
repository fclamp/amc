cp AmLocalSettings.php /export/home/emu/master/web/objects/am/
cp webmedia.php /export/home/emu/master/web/objects/am/
cp ResultsLists.php /export/home/emu/master/web/objects/am/
cp DisplayObjects.php /export/home/emu/master/web/objects/am/
cp media.php /export/home/emu/master/web/objects/am/
cp QueryForms.php /export/home/emu/master/web/objects/am/
